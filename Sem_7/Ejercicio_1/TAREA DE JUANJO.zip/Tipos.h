#ifndef PERSONA_TIPOS_H
#define PERSONA_TIPOS_H

#include <iostream>

using namespace std;

typedef std::string texto;
typedef int entero;

#endif //PERSONA_TIPOS_H

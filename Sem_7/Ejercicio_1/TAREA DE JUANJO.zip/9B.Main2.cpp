#include "CAlumno.h"
#include "CCurso.h"

int main()
{
// Crear un puntero a CAlumno y A CCurso usando un constructor por asignación


// Obtener sus créditos con el método getCreditos

// usar el metodo aprobar (para aprobar el curso)

// Obtener sus créditos después de aprobar

// liberar memoria dinamica

    return 0;
}


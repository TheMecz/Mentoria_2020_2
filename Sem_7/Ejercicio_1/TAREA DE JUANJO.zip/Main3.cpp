#include "Funciones.h"

int main() {

// crear un array dinámica de alumnos usando el constructor por asignación

// implementar la funcion de búsqueda del alumno con la mayor cantidad de creditos aprobados e imprimir la informacion correspondiente


    return 0;
}
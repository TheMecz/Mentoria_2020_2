
#include "CProfesor.h"

const texto &CProfesor::getNombre() const {
    return nombre;
}

void CProfesor::setNombre(const texto &nombre) {

}

const texto &CProfesor::getApellidos() const {
    return apellidos;
}

void CProfesor::setApellidos(const texto &apellidos) {


}

entero CProfesor::getEdad() const {

    return edad;

}

void CProfesor::setEdad(entero edad) {


}

entero CProfesor::getHorasDictado() const {

    return horasDictado;
}

void CProfesor::setHorasDictado(entero horasDictado) {


}
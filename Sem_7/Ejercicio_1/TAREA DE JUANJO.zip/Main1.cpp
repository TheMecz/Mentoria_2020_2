#include "Funciones.h"

int main() {
    cout<<"Alumno:\n";
// crear un puntero a objeto CAlumno

// ingresar datos del alumno con funcion externa de pedir_datos()
// crear un puntero a objeto CAlumno

// ingresar datos del profesor con funcion externa de pedir_datos(), usar plantillas para poder usar la misma funcion con CAlumno


// imprimir datos del alumno y profesor con la funcion genérica mostrar_datos()

    return 0;
}
